print(False or (1/1>0))
print(1/2 > 0 and True)


a=True
x=1
d=x<2
print(d)

a=True
x=1
d!=a or x%2
print(d)

a=True
x=1
d=a%2 !=x
print(d)